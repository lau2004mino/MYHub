# Instagram Unfollow Unfollowers Bot
An Instagram bot that unfollows unfollowers. It uses the <a href ="https://github.com/LevPasha/Instagram-API-python">Unofficial instagram API</a> by LevPasha.

# Video tutorial
I made a short <a href ="https://www.youtube.com/watch?v=L4KHj9rcteE">video</a> about the project and tried to explain the process.
