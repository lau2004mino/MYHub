def Username():
    return "DeinUsername"
def Password():
    return "DeinPassword"

